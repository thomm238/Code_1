// michael thompspon code 1 #7
let scene=1;
let car1, car2, car3;
let x = 10;

let frog = 150;
let bug;

function setup() {
  createCanvas(600, 400);
  
  rectMode(CENTER)
  car1 = new Car(300, 10);
  car2 = new Car(200, 200);
  car3 = new Car(400, 270);
  car4 = new Car(450, 100);
  frog1 = new Frog(10, 1);
 
}

function s1() {
  text("Act 1", 100, 100);
 
  // bug1= new Jitter();
}

function s2() {
  text("Act 2", 100, 100)
}

function s3() {
  text("Act 3", 100, 100)
}

function draw() {
  background(235,82,52);
 if (scene == 1) {
    s1();
  } else if (scene == 2) {
    s2();
  } else if (scene == 3) {
    s3();
  }
  if (frog1.frogX > width) {
    frog.frogX = 0
    scene++;
  }
  
  // bug1.move();
  //bug.show();

  car1.show();

  car1.checkCollision();

  car2.show();

  car2.checkCollision();

  car3.show();

  car3.checkCollision();

  car4.show();

  car4.checkCollision();

  frog1.show();



  if (keyIsPressed == true) {
    frog.frogY--


    if (keyCode == UP_ARROW) {
      frog1.frogY -= 3
    } else if (keyCode == DOWN_ARROW) {
      frog1.frogY += 3
    } else if (keyCode == RIGHT_ARROW) {
      frog1.frogX += 3
    } else if (keyCode == LEFT_ARROW) {
      frog1.frogX -= 3
    }


  }

}

// class Jitter {
//   constructor() {
//     this.x = random(width);
//     this.y = random(height);
//     this.diameter = random(10, 30);
//     this.speed = 1;
//   }

class Frog {
  constructor(x, y) {
    this.frogX = x;
    this.frogY = y;
  }
  show() {
    ellipse(this.frogX, this.frogY, 50, 50)
  }
}

class Car {
  constructor(x, y) {
    this.carX = x;
    this.carY = y;
  }
  show() {
    fill(153,32,8)
    rect(this.carX, this.carY, 600, 20)

  }


  checkCollision() {
    if ((this.carX > frog1.frogX - 150) && (this.carX < frog1.frogX + 315) && (this.carY > frog1.frogY - 25) && (this.carY < frog1.frogY + 25)) {
      frog1.frogY = height - 10;
    }


  }

}