let car1, car2, car3;
let frog1;
let scene = 1;
let dialogBox
let dialog

function setup() {
  createCanvas(600, 400);
  rectMode(CENTER);
  
  

  // this is an instance of the object that runs the constructor of the class Car

  car1 = new Car(100, 100, color(64, 40, 1));
  car2 = new Car(400, 140, color(64, 40, 1));
  car3 = new Car(200, 180, color(64, 40, 1));
  car10 = new Car(800, 220, color(64, 40, 1));
  car11 = new Car(50, 220, color(64, 40, 1));
  car12 = new Car(500, 260, color(64, 40, 1));
  car13 = new Car(-250, 260, color(64, 40, 1));
  car14 = new Car(90, 300, color(64, 40, 1));
  car15 = new Car(850, 300, color(64, 40, 1));
  car16 = new Car(500, 60, color(64, 40, 1));
  car17 = new Car(-250, 60, color(64, 40, 1));
  car18 = new Car(-2, 20, color(64, 40, 1));


  car19 = new Car(180, 130, color(64, 40, 1));
  car20 = new Car(400, 170, color(64, 40, 1));
  car21 = new Car(200, 210, color(64, 40, 1));
  car22 = new Car(900, 250, color(64, 40, 1));
  car23 = new Car(150, 250, color(64, 40, 1));
  car24 = new Car(600, 290, color(64, 40, 1));
  car25 = new Car(-150, 290, color(64, 40, 1));
  car26 = new Car(400, 330, color(64, 40, 1));
  car27 = new Car(850, 50, color(64, 40, 1));
  car28 = new Car(500, 90, color(64, 40, 1));
  car29 = new Car(-250, 90, color(64, 40, 1));
  car30 = new Car(-2, 50, color(64, 40, 1));

  car31 = new Car(100, 100, color(64, 40, 1));
  car32 = new Car(400, 140, color(64, 40, 1));
  car33 = new Car(200, 180, color(64, 40, 1));
  car34 = new Car(800, 220, color(64, 40, 1));
  car35 = new Car(50, 220, color(64, 40, 1));
  car36 = new Car(500, 260, color(64, 40, 1));
  car37 = new Car(-250, 260, color(64, 40, 1));
  car38 = new Car(100, 300, color(64, 40, 1));
  car39 = new Car(850, 300, color(64, 40, 1));
  car40 = new Car(500, 60, color(64, 40, 1));
  car41 = new Car(-250, 60, color(64, 40, 1));
  car42 = new Car(500, 350, color(64, 40, 1));
  car50 = new Car(500,350,color(0));

  frog1 = new Frog(width / 2, height - 5);
  
  kin1 = new Kin(100,300)
  kin2 = new Kin(60,260)
    kin3 = new Kin(100,220)
  kin4 = new Kin(60,180)
   kin5 = new Kin(100,140)
  kin6 = new Kin(60,100)
    kin7 = new Kin(100,60)
  kin8 = new Kin(60,20)
  
    kin9 = new Kin(460,300)
  kin10 = new Kin(500,260)
    kin11 = new Kin(460,220)
  kin12 = new Kin(500,180)
   kin13 = new Kin(460,140)
  kin14 = new Kin(500,100)
    kin15 = new Kin(460,60)
  kin16 = new Kin(500,20)
}

function draw() {
  background(220);


  if (scene == 1) {
    Scene1();
  } else if (scene == 2) {
    Scene2();
  } else if (scene == 3) {
    Scene3();
  } else if (scene == 4) {
    Scene4();
  } else if (scene == 5) {
    Scene5();
  } 

  frog1.show();

  if (keyIsPressed == true) {
    if (keyCode == UP_ARROW) {
      frog1.frogY -= 3;
    }
  }
  if (keyIsPressed == true) {
    if (keyCode == DOWN_ARROW) {
      frog1.frogY += 3;
    }
  }
  if (keyIsPressed == true) {
    if (keyCode == RIGHT_ARROW) {
      frog1.frogX += 3;
    }
  }
  if (keyIsPressed == true) {
    if (keyCode == LEFT_ARROW) {
      frog1.frogX -= 3;
    }
  }

  if (frog1.frogY < 0) {
    frog1.frogY = height;
    scene++;
  }
  print(scene);
}
function Scene1(){
  background(189, 109, 0)
  textSize(50);
  fill(245, 236, 66)
text('Into The Pumpkin Patch', 25, 200);

  textSize(30);
text('By Michael Thompson', 25, 225);


  textSize(15);
text('Use arrow keys to continue', 200, 350);
}

function Scene2() {
  background(189, 109, 0)
  
    textSize(15);
text('Lvl 1', 10, 390);

  
  car1.show();
  car1.checkCollision();

  car2.show();
  car2.checkCollision();

  car3.show();
  car3.checkCollision();

  car10.show();
  car10.checkCollision();

  car11.show();
  car11.checkCollision();

  car12.show();
  car12.checkCollision();

  car13.show();
  car13.checkCollision();

  car14.show();
  car14.checkCollision();

  car15.show();
  car15.checkCollision();

  car16.show();
  car16.checkCollision();

  car17.show();
  car17.checkCollision();

  car18.show();
  car18.checkCollision();
}


function Scene3() {

  background(209, 132, 29)
  
     textSize(15);
text('Lvl 2', 10, 390);
  
  car19.show();
  car19.checkCollision();

  car20.show();
  car20.checkCollision();


  car21.show();
  car21.checkCollision();

  car22.show();
  car22.checkCollision();

  car23.show();
  car23.checkCollision();

  car24.show();
  car24.checkCollision();

  car25.show();
  car25.checkCollision();

  car26.show();
  car26.checkCollision();

  car27.show();
  car27.checkCollision();

  car28.show();
  car28.checkCollision();

  car29.show();
  car29.checkCollision();

  car30.show();
  car30.checkCollision();
}

function Scene4() {
background(237, 177, 47)
  
       textSize(15);
text('Lvl 3', 10, 390);
  
   car31.show();
  car31.checkCollision();

  car32.show();
  car32.checkCollision();

  car33.show();
  car33.checkCollision();

  car34.show();
  car34.checkCollision();

  car35.show();
  car35.checkCollision();

  car36.show();
  car12.checkCollision();

  car36.show();
  car36.checkCollision();

  car37.show();
  car37.checkCollision();

  car38.show();
  car38.checkCollision();

  car39.show();
  car39.checkCollision();

  car40.show();
  car40.checkCollision();

  car41.show();
  car41.checkCollision();
  
  car42.show();
  car42.checkCollision();
}
  function Scene5(){
    background(144, 245, 66)
   // car50.show()
    kin1.show();
  kin2.show();
    kin3.show();
    kin4.show();
   kin5.show();
    kin6.show();
    kin7.show();
    kin8.show();
    
        kin9.show();
  kin10.show();
    kin11.show();
    kin12.show();
   kin13.show();
    kin14.show();
    kin15.show();
    kin16.show();
    fill(237, 177, 47)
    rect(300,100,100,600)
    


    
  

  
}
// class is the cookie cutter to make individual object
class Car {
  // setup of the class, where variables are declared
  constructor(x, y, c) {
    this.carX = x;
    this.carY = y;
    this.carC = c;
  }

  // this is a method, which is a function that lives under object
  move() {
    this.carX += 1;

    if (this.carX > width) {
      this.carX = 0;
    }
  }

  show() {
    fill(this.carC);
    rect(this.carX, this.carY, 700, 5);
  }

  checkCollision() {
    if ((this.carX > frog1.frogX - 360) && (this.carX < frog1.frogX + 360) && (this.carY > frog1.frogY - 15) && (this.carY < frog1.frogY + 15)) {
      frog1.frogY = height - 10;
    }
  }

}

class Frog {

  constructor(x, y) {
    this.frogX = x;
    this.frogY = y;
  }

  show() {
    noStroke();
    fill(235, 158, 52);
    ellipse(this.frogX, this.frogY, 30, 30);
    fill(0)
    ellipse(this.frogX - 5, this.frogY, 5, 5)
    ellipse(this.frogX + 5, this.frogY, 5, 5)
    ellipse(this.frogX, this.frogY + 7, 5, 5)
    fill(69, 45, 12)
    rect(this.frogX, this.frogY - 15, 3, 5)


  }
}

class Kin {

  constructor(x, y) {
      this.kinX = x;
    this.kinY = y;
  }

  show() {
    noStroke();
    fill(235, 158, 52);
    ellipse(this.kinX, this.kinY, 30, 30);
    fill(0)
    ellipse(this.kinX - 5, this.kinY, 5, 5)
    ellipse(this.kinX + 5, this.kinY, 5, 5)
    arc(this.kinX, this.kinY + 8, 10, 10, TWO_PI, PI);
    fill(69, 45, 12)
    rect(this.kinX, this.kinY - 15, 3, 5)

}
  }